# Security Specification - LA PORRA DEL MUNDIAL 2026

## 1. Data Invariants
- A user can only create/update their own profile.
- A user can only register as a regular user (not admin) via the client.
- Only an admin can change the `isPaid` and `isAdmin` status of a user.
- A user can only write predictions for themselves.
- Predictions must follow the correct schema (e.g., top3 must be an array of size 3).
- Usernames must be between 3 and 30 characters.
- Document IDs for predictions must be specifically formatted.

## 2. The "Dirty Dozen" Payloads (Deny List)
1. **Identity Spoofing**: Write to `/users/other_uid` as `my_uid`.
2. **Privilege Escalation**: Set `isAdmin: true` on my own profile.
3. **Payment Bypass**: Set `isPaid: true` on my own profile.
4. **Shadow Field Injection**: Add `bonusPoints: 999` to a user profile.
5. **Prediction Hijacking**: Update `/predictions/other_uid_f1`.
6. **Value Poisoning**: Set `top3: ["invalid", "ids", "too_long_prediction_value_test_test_test"]`.
7. **Size Attack**: Save a `displayName` that is 1MB long.
8. **Relational Break**: Save a prediction with a `userId` that doesn't match the auth UID.
9. **Timestamp Spoofing**: Send a `updatedAt` from the future (client-provided).
10. **ID Poisoning**: Use a document ID that is 2KB long.
11. **Direct Point Manipulation**: Update `totalPoints` directly from the client.
12. **Admin Spoofing**: Try to list all users as a non-admin (if sensitive data exists).

## 3. Test Runner (Conceptual)
All the above payloads MUST return `PERMISSION_DENIED`.
