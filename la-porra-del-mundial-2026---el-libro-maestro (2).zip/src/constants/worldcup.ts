export interface Team {
  id: string;
  name: string;
  flag: string;
}

export interface Group {
  id: string;
  name: string;
  teams: Team[];
}

export const GROUPS: Group[] = [
  { id: 'A', name: 'Grupo A', teams: [{ id: 'mex', name: 'México', flag: '🇲🇽' }, { id: 'rsa', name: 'Sudáfrica', flag: '🇿🇦' }, { id: 'kor', name: 'Corea del Sur', flag: '🇰🇷' }, { id: 'cze', name: 'Chequia', flag: '🇨🇿' }] },
  { id: 'B', name: 'Grupo B', teams: [{ id: 'can', name: 'Canadá', flag: '🇨🇦' }, { id: 'bih', name: 'Bosnia y Herz.', flag: '🇧🇦' }, { id: 'qat', name: 'Catar', flag: '🇶🇦' }, { id: 'sui', name: 'Suiza', flag: '🇨🇭' }] },
  { id: 'C', name: 'Grupo C', teams: [{ id: 'bra', name: 'Brasil', flag: '🇧🇷' }, { id: 'mar', name: 'Marruecos', flag: '🇲🇦' }, { id: 'hai', name: 'Haití', flag: '🇭🇹' }, { id: 'sco', name: 'Escocia', flag: '🏴󠁧󠁢󠁳󠁣󠁴󠁿' }] },
  { id: 'D', name: 'Grupo D', teams: [{ id: 'usa', name: 'Estados Unidos', flag: '🇺🇸' }, { id: 'par', name: 'Paraguay', flag: '🇵🇾' }, { id: 'aus', name: 'Australia', flag: '🇦🇺' }, { id: 'tur', name: 'Turquía', flag: '🇹🇷' }] },
  { id: 'E', name: 'Grupo E', teams: [{ id: 'ger', name: 'Alemania', flag: '🇩🇪' }, { id: 'cuw', name: 'Curazao', flag: '🇨🇼' }, { id: 'civ', name: 'Costa de Marfil', flag: '🇨🇮' }, { id: 'ecu', name: 'Ecuador', flag: '🇪🇨' }] },
  { id: 'F', name: 'Grupo F', teams: [{ id: 'ned', name: 'Países Bajos', flag: '🇳🇱' }, { id: 'jpn', name: 'Japón', flag: '🇯🇵' }, { id: 'swe', name: 'Suecia', flag: '🇸🇪' }, { id: 'tun', name: 'Túnez', flag: '🇹🇳' }] },
  { id: 'G', name: 'Grupo G', teams: [{ id: 'bel', name: 'Bélgica', flag: '🇧🇪' }, { id: 'egy', name: 'Egipto', flag: '🇪🇬' }, { id: 'irn', name: 'Irán', flag: '🇮🇷' }, { id: 'nzl', name: 'Nueva Zelanda', flag: '🇳🇿' }] },
  { id: 'H', name: 'Grupo H', teams: [{ id: 'esp', name: 'España', flag: '🇪🇸' }, { id: 'cpv', name: 'Cabo Verde', flag: '🇨🇻' }, { id: 'ksa', name: 'Arabia Saudita', flag: '🇸🇦' }, { id: 'uru', name: 'Uruguay', flag: '🇺🇾' }] },
  { id: 'I', name: 'Grupo I', teams: [{ id: 'fra', name: 'Francia', flag: '🇫🇷' }, { id: 'sen', name: 'Senegal', flag: '🇸🇳' }, { id: 'irq', name: 'Irak', flag: '🇮🇶' }, { id: 'nor', name: 'Noruega', flag: '🇳🇴' }] },
  { id: 'J', name: 'Grupo J', teams: [{ id: 'arg', name: 'Argentina', flag: '🇦🇷' }, { id: 'alg', name: 'Argelia', flag: '🇩🇿' }, { id: 'aut', name: 'Austria', flag: '🇦🇹' }, { id: 'jor', name: 'Jordania', flag: '🇯🇴' }] },
  { id: 'K', name: 'Grupo K', teams: [{ id: 'por', name: 'Portugal', flag: '🇵🇹' }, { id: 'cod', name: 'RD Congo', flag: '🇨🇩' }, { id: 'uzb', name: 'Uzbekistán', flag: '🇺🇿' }, { id: 'col', name: 'Colombia', flag: '🇨🇴' }] },
  { id: 'L', name: 'Grupo L', teams: [{ id: 'eng', name: 'Inglaterra', flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿' }, { id: 'cro', name: 'Croacia', flag: '🇭🇷' }, { id: 'gha', name: 'Ghana', flag: '🇬🇭' }, { id: 'pan', name: 'Panamá', flag: '🇵🇦' }] }
];

export const PHASE_DEADLINES = {
  PHASE_1: new Date('2026-06-11T17:00:00Z'),
};

export const SCORING_RULES = {
  F1_TOP3_MEMBER: 1,
  F1_EXACT_POS: 2,
  F2_OCTAVOS: 4, // R32 matches
  F2_CUARTOS: 3, // R16 matches
  F2_SEMIS: 2,   // R8 matches
  F2_FINAL: 1,   // Substituted by user's logic? User said Octavos(4), Cuartos(3), Semis(2), Final(1).
  DAILY_EXACT: 4,
  DAILY_SIGN: 2,
  FINAL_EXACT: 30,
  FINAL_DIFF: 15,
  FINAL_SIGN: 10,
};

export interface DailyMatch {
  id: string;
  homeTeam: Team;
  awayTeam: Team;
  date: string;
}

export const DAILY_MATCHES: DailyMatch[] = [
  { id: 'm1', homeTeam: { id: 'mex', name: 'México', flag: '🇲🇽' }, awayTeam: { id: 'rsa', name: 'Sudáfrica', flag: '🇿🇦' }, date: '2026-06-11' },
  { id: 'm2', homeTeam: { id: 'can', name: 'Canadá', flag: '🇨🇦' }, awayTeam: { id: 'bih', name: 'Bosnia y Herz.', flag: '🇧🇦' }, date: '2026-06-12' },
  { id: 'm3', homeTeam: { id: 'usa', name: 'USA', flag: '🇺🇸' }, awayTeam: { id: 'par', name: 'Paraguay', flag: '🇵🇾' }, date: '2026-06-13' },
  { id: 'm4', homeTeam: { id: 'ger', name: 'Alemania', flag: '🇩🇪' }, awayTeam: { id: 'cuw', name: 'Curazao', flag: '🇨🇼' }, date: '2026-06-14' },
  { id: 'm5', homeTeam: { id: 'ned', name: 'Países Bajos', flag: '🇳🇱' }, awayTeam: { id: 'jpn', name: 'Japón', flag: '🇯🇵' }, date: '2026-06-15' },
  { id: 'm6', homeTeam: { id: 'esp', name: 'España', flag: '🇪🇸' }, awayTeam: { id: 'uru', name: 'Uruguay', flag: '🇺🇾' }, date: '2026-06-16' },
  { id: 'm7', homeTeam: { id: 'arg', name: 'Argentina', flag: '🇦🇷' }, awayTeam: { id: 'jor', name: 'Jordania', flag: '🇯🇴' }, date: '2026-06-17' },
  { id: 'm8', homeTeam: { id: 'bra', name: 'Brasil', flag: '🇧🇷' }, awayTeam: { id: 'mar', name: 'Marruecos', flag: '🇲🇦' }, date: '2026-06-18' },
  { id: 'm9', homeTeam: { id: 'fra', name: 'Francia', flag: '🇫🇷' }, awayTeam: { id: 'nor', name: 'Noruega', flag: '🇳🇴' }, date: '2026-06-19' },
  { id: 'm10', homeTeam: { id: 'por', name: 'Portugal', flag: '🇵🇹' }, awayTeam: { id: 'col', name: 'Colombia', flag: '🇨🇴' }, date: '2026-06-20' },
  { id: 'm11', homeTeam: { id: 'eng', name: 'Inglaterra', flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿' }, awayTeam: { id: 'cro', name: 'Croacia', flag: '🇭🇷' }, date: '2026-06-21' },
  { id: 'm12', homeTeam: { id: 'bel', name: 'Bélgica', flag: '🇧🇪' }, awayTeam: { id: 'nzl', name: 'Nueva Zelanda', flag: '🇳🇿' }, date: '2026-06-22' },
];
