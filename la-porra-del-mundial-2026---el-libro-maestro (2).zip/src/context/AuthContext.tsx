import React, { createContext, useContext, useEffect, useState } from 'react';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { auth, db } from '../lib/firebase';

interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  isAdmin: boolean;
  isPaid: boolean;
  totalPoints: number;
  f1Points: number;
  f2Points: number;
  dailyPoints: number;
  f3Points: number;
  titles: string[];
  stats: {
    exactDaily: number;
  };
}

interface AuthContextType {
  user: FirebaseUser | null;
  profile: UserProfile | null;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType>({ user: null, profile: null, loading: true });

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      if (u) {
        const userDoc = await getDoc(doc(db, 'users', u.uid));
        if (userDoc.exists()) {
          setProfile(userDoc.data() as UserProfile);
        } else {
          // Initialize profile
          const isAdmin = u.email === 'irenegadom@gmail.com';
          const newProfile: UserProfile = {
            uid: u.uid,
            displayName: u.displayName || u.email?.split('@')[0] || 'Jugador',
            email: u.email || '',
            isAdmin: isAdmin,
            isPaid: isAdmin,
            totalPoints: 0,
            f1Points: 0,
            f2Points: 0,
            dailyPoints: 0,
            f3Points: 0,
            titles: isAdmin ? ['ADMIN', 'MAESTRO'] : ['NOVATO'],
            stats: { exactDaily: 0 }
          };
          await setDoc(doc(db, 'users', u.uid), newProfile);
          setProfile(newProfile);
        }
      } else {
        setProfile(null);
      }
      setLoading(false);
    });
    return unsubscribe;
  }, []);

  return (
    <AuthContext.Provider value={{ user, profile, loading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
