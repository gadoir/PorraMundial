import React from 'react';
import { motion } from 'motion/react';
import { Trophy, GitFork } from 'lucide-react';

export const BracketPhase = () => {
  return (
    <div className="h-full flex flex-col space-y-8">
      <header>
        <h2 className="text-4xl font-black uppercase tracking-tighter italic">FASE 2: <span className="text-[#d4af37]">EL BRACKET</span></h2>
        <p className="text-xs font-bold text-slate-500 uppercase tracking-widest mt-1 opacity-60">El camino a la gloria desde Dieciseisavos de Final</p>
      </header>

      <div className="flex-1 glass rounded-[40px] overflow-hidden relative flex items-center justify-center border border-white/5 bg-black/40">
        <div className="absolute inset-0 bg-gradient-to-br from-amber-500/5 to-transparent pointer-events-none" />
        
        <div className="text-center relative z-10 p-12">
          <div className="w-24 h-24 bg-white/5 rounded-3xl border border-white/10 flex items-center justify-center mx-auto mb-8 rotate-12">
            <GitFork size={48} className="text-[#d4af37]" />
          </div>
          <h3 className="text-2xl font-black uppercase tracking-tighter mb-4 italic">Bracket Interactivo</h3>
          <p className="text-sm text-slate-400 max-w-md mx-auto leading-relaxed mb-8">
            El bracket se activará automáticamente una vez se definan los clasificados de la Fase de Grupos. Podrás seleccionar tus ganadores en cada ronda.
          </p>
          <div className="flex justify-center gap-4">
             <div className="px-6 py-2 rounded-full border border-white/10 text-[10px] font-black uppercase tracking-[0.2em] text-slate-500">Próximamente</div>
          </div>
        </div>

        {/* Visual Decoration */}
        <div className="absolute bottom-12 left-12 right-12 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
      </div>
    </div>
  );
};
