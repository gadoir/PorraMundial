import React, { useState, useEffect } from 'react';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../context/AuthContext';
import { GROUPS, Team, PHASE_DEADLINES } from '../constants/worldcup';
import { motion } from 'motion/react';
import { CheckCircle2, AlertCircle } from 'lucide-react';
import { cn } from '../lib/utils';

export const GroupPhase = () => {
  const { profile } = useAuth();
  const [predictions, setPredictions] = useState<Record<string, string[]>>({});
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  const isClosed = new Date() > PHASE_DEADLINES.PHASE_1;

  useEffect(() => {
    const loadPredictions = async () => {
      if (!profile) return;
      const preds: Record<string, string[]> = {};
      for (const group of GROUPS) {
        const d = await getDoc(doc(db, 'predictions', profile.uid, 'groups', group.id));
        if (d.exists()) {
          preds[group.id] = d.data().top3;
        } else {
          preds[group.id] = [];
        }
      }
      setPredictions(preds);
    };
    loadPredictions();
  }, [profile]);

  const toggleTeam = (groupId: string, teamId: string) => {
    if (isClosed) return;
    setPredictions(prev => {
      const current = prev[groupId] || [];
      if (current.includes(teamId)) {
        return { ...prev, [groupId]: current.filter(id => id !== teamId) };
      }
      if (current.length >= 3) return prev;
      return { ...prev, [groupId]: [...current, teamId] };
    });
  };

  const handleSave = async () => {
    if (!profile || isClosed) return;
    setSaving(true);
    try {
      for (const groupId in predictions) {
        await setDoc(doc(db, 'predictions', profile.uid, 'groups', groupId), {
          userId: profile.uid,
          groupId,
          top3: predictions[groupId],
          updatedAt: new Date().toISOString()
        });
      }
      setMessage({ type: 'success', text: '¡Pronósticos de grupos guardados correctamente!' });
    } catch (e) {
      setMessage({ type: 'error', text: 'Error al guardar los pronósticos.' });
    }
    setSaving(false);
    setTimeout(() => setMessage(null), 3000);
  };

  return (
    <div className="space-y-8">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h2 className="text-4xl font-black uppercase tracking-tighter italic">FASE 1: <span className="text-[#d4af37]">GRUPOS</span></h2>
          <p className="text-xs font-bold text-slate-500 uppercase tracking-widest mt-1 opacity-60">Selecciona el Top 3 de cada grupo para El Libro Maestro</p>
        </div>
        {isClosed ? (
          <div className="px-5 py-2.5 bg-red-500/10 text-red-500 border border-red-500/30 rounded-full font-bold text-[10px] uppercase tracking-widest flex items-center gap-3">
            <AlertCircle size={16} /> El plazo ha expirado
          </div>
        ) : (
          <button 
            onClick={handleSave}
            disabled={saving}
            className="group relative px-10 py-3.5 bg-[#d4af37] text-[#05070a] font-black uppercase tracking-widest rounded-full transition-all hover:scale-105 active:scale-95 disabled:opacity-50 gold-glow overflow-hidden"
          >
            <span className="relative z-10">{saving ? 'Guardando...' : 'Fijar Pronósticos'}</span>
            <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
          </button>
        )}
      </header>

      {message && (
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className={cn(
            "p-5 rounded-2xl border-2 font-bold uppercase text-[10px] tracking-widest flex items-center gap-4 shadow-xl",
            message.type === 'success' ? "bg-green-500/10 border-green-500/30 text-green-400" : "bg-red-500/10 border-red-500/30 text-red-400"
          )}
        >
          <CheckCircle2 size={18} /> {message.text}
        </motion.div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {GROUPS.map(group => (
          <div key={group.id} className="glass rounded-[32px] overflow-hidden card-gradient border border-white/5 transition-all hover:border-[#d4af37]/30 group/card">
            <div className="bg-white/5 p-5 flex justify-between items-center border-b border-white/5">
              <span className="font-black uppercase italic tracking-tighter text-white group-hover/card:text-[#d4af37] transition-colors">{group.name}</span>
              <div className="flex gap-1">
                {[1,2,3].map(i => (
                  <div key={i} className={cn(
                    "w-1.5 h-1.5 rounded-full transition-colors",
                    (predictions[group.id]?.length || 0) >= i ? "bg-[#d4af37] gold-glow" : "bg-slate-700"
                  )} />
                ))}
              </div>
            </div>
            <div className="p-5 space-y-3">
              {group.teams.map(team => {
                const pos = predictions[group.id]?.indexOf(team.id);
                const isSelected = pos !== undefined && pos !== -1;
                
                return (
                  <button
                    key={team.id}
                    onClick={() => toggleTeam(group.id, team.id)}
                    className={cn(
                      "w-full flex items-center justify-between p-3.5 rounded-xl border transition-all duration-300 group",
                      isSelected 
                        ? "border-[#d4af37]/40 bg-[#d4af37]/5 translate-x-2" 
                        : "border-white/5 bg-black/20 hover:border-white/20 hover:bg-black/40"
                    )}
                  >
                    <div className="flex items-center gap-4">
                      <span className="text-2xl grayscale group-hover:grayscale-0 transition-all scale-100 group-hover:scale-110 drop-shadow-md">
                        {team.flag}
                      </span>
                      <span className={cn(
                        "font-bold text-[11px] uppercase tracking-wide transition-colors", 
                        isSelected ? "text-white" : "text-slate-400 group-hover:text-slate-300"
                      )}>
                        {team.name}
                      </span>
                    </div>
                    {isSelected && (
                      <motion.div 
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="w-7 h-7 bg-[#d4af37] text-[#05070a] flex items-center justify-center rounded-lg font-black text-xs gold-glow"
                      >
                        {pos + 1}º
                      </motion.div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
