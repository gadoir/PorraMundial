import React from 'react';
import { motion } from 'motion/react';
import { Trophy, Target } from 'lucide-react';

export const FinalPhase = () => {
  return (
    <div className="h-full flex flex-col space-y-8">
      <header>
        <h2 className="text-4xl font-black uppercase tracking-tighter italic">LA GRAN <span className="text-[#d4af37]">FINAL</span></h2>
        <p className="text-xs font-bold text-slate-500 uppercase tracking-widest mt-1 opacity-60">El pronóstico definitivo del Libero Maestro</p>
      </header>

      <div className="flex-1 glass rounded-[40px] overflow-hidden relative flex items-center justify-center border border-white/5 bg-black/40">
        <div className="absolute inset-0 bg-gradient-to-tr from-blue-500/5 to-transparent pointer-events-none" />
        
        <div className="text-center relative z-10 p-12">
          <div className="w-24 h-24 bg-gradient-to-br from-amber-400 to-yellow-600 rounded-full border-4 border-white/20 flex items-center justify-center mx-auto mb-8 gold-glow animate-pulse">
            <Trophy size={48} className="text-white drop-shadow-xl" />
          </div>
          <h3 className="text-2xl font-black uppercase tracking-tighter mb-4 italic text-white">¿Quién levantará la copa?</h3>
          <p className="text-sm text-slate-400 max-w-lg mx-auto leading-relaxed mb-10">
            Aquí deberás elegir al Campeón del Mundo y el resultado exacto de la Final. Esta sección otorga la mayor cantidad de puntos de la competición.
          </p>
          
          <div className="flex flex-col md:flex-row justify-center gap-6">
             <div className="px-8 py-4 glass bg-white/5 rounded-2xl border border-white/10 flex flex-col items-center">
               <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1">Acierto Campeón</span>
               <span className="text-xl font-black text-[#d4af37]">30 PTS</span>
             </div>
             <div className="px-8 py-4 glass bg-white/5 rounded-2xl border border-white/10 flex flex-col items-center">
               <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1">Resultado Exacto</span>
               <span className="text-xl font-black text-[#d4af37]">15 PTS</span>
             </div>
             <div className="px-8 py-4 glass bg-white/5 rounded-2xl border border-white/10 flex flex-col items-center">
               <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1">Signo Final</span>
               <span className="text-xl font-black text-[#d4af37]">10 PTS</span>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};
