import React, { useState, useEffect } from 'react';
import { doc, setDoc, getDoc, collection, onSnapshot } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../context/AuthContext';
import { DAILY_MATCHES } from '../constants/worldcup';
import { motion } from 'motion/react';
import { Target, Save, CheckCircle2, XCircle } from 'lucide-react';
import { cn } from '../lib/utils';
import { calculateDailyPoints } from '../services/scoring';

export const DailyPhase = () => {
  const { profile } = useAuth();
  const [predictions, setPredictions] = useState<Record<string, { home: number, away: number }>>({});
  const [officialResults, setOfficialResults] = useState<Record<string, any>>({});
  const [saving, setSaving] = useState<string | null>(null);

  useEffect(() => {
    const unsubOfficial = onSnapshot(collection(db, 'official_matches'), (snap) => {
      const results: Record<string, any> = {};
      snap.docs.forEach(d => { results[d.id] = d.data(); });
      setOfficialResults(results);
    });

    const load = async () => {
      if (!profile) return;
      const preds: any = {};
      for (const m of DAILY_MATCHES) {
        const d = await getDoc(doc(db, 'predictions', profile.uid, 'daily', m.id));
        if (d.exists()) {
          preds[m.id] = { home: d.data().homeScore, away: d.data().awayScore };
        }
      }
      setPredictions(preds);
    };
    load();
    return () => unsubOfficial();
  }, [profile]);

  const updateScore = (matchId: string, side: 'home' | 'away', val: string) => {
    const num = parseInt(val) || 0;
    setPredictions(prev => ({
      ...prev,
      [matchId]: { ... (prev[matchId] || { home: 0, away: 0 }), [side]: num }
    }));
  };

  const handleSave = async (matchId: string) => {
    if (!profile) return;
    setSaving(matchId);
    try {
      await setDoc(doc(db, 'predictions', profile.uid, 'daily', matchId), {
        userId: profile.uid,
        matchId,
        homeScore: predictions[matchId]?.home || 0,
        awayScore: predictions[matchId]?.away || 0,
        updatedAt: new Date().toISOString()
      });
    } catch (e) {
      console.error(e);
    }
    setSaving(null);
  };

  return (
    <div className="space-y-8 h-full flex flex-col">
      <header>
        <h2 className="text-4xl font-black uppercase tracking-tighter italic">PARTIDO <span className="text-[#d4af37]">DEL DÍA</span></h2>
        <p className="text-xs font-bold text-slate-500 uppercase tracking-widest mt-1 opacity-60">Pronostica el marcador exacto de la jornada actual</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 overflow-y-auto pr-2">
        {DAILY_MATCHES.map(match => {
          const pred = predictions[match.id];
          const official = officialResults[match.id];
          const hasResult = official && official.homeResult !== null && official.awayResult !== null;
          
          let points = 0;
          if (hasResult && pred) {
            points = calculateDailyPoints(official.homeResult, official.awayResult, pred.home, pred.away);
          }

          const isExact = points === 10;
          const isSign = points === 5;

          return (
            <div key={match.id} className={cn(
              "glass rounded-[32px] p-8 flex flex-col md:flex-row items-center justify-between gap-8 card-gradient border transition-all group relative overflow-hidden",
              hasResult ? (isExact ? "border-green-500/50 shadow-[0_0_20px_rgba(34,197,94,0.2)]" : isSign ? "border-blue-500/50" : "border-red-500/20") : "border-white/5 hover:border-[#d4af37]/20"
            )}>
              {hasResult && (
                <div className={cn(
                  "absolute top-0 right-0 px-4 py-1 text-[8px] font-black uppercase tracking-[0.2em]",
                  isExact ? "bg-green-500 text-white" : isSign ? "bg-blue-500 text-white" : "bg-red-500/20 text-red-400"
                )}>
                  {isExact ? "Exacto +10" : isSign ? "Signo +5" : "Fallado +0"}
                </div>
              )}

              <div className="flex items-center gap-5 flex-1 justify-end">
                <div className="text-right">
                  <span className="font-black uppercase text-[10px] block leading-tight text-white/60 group-hover:text-white transition-colors">{match.homeTeam.name}</span>
                  {hasResult && <span className="text-sm font-black text-slate-500">{official.homeResult}</span>}
                </div>
                <span className="text-3xl drop-shadow-lg">{match.homeTeam.flag}</span>
                <input 
                  type="number" 
                  disabled={hasResult}
                  value={pred?.home || 0}
                  onChange={(e) => updateScore(match.id, 'home', e.target.value)}
                  className={cn(
                    "w-14 h-14 glass rounded-2xl text-center font-black text-2xl outline-none transition-all",
                    hasResult ? "text-slate-500 border-white/5" : "text-[#d4af37] focus:border-[#d4af37] border-white/10"
                  )}
                />
              </div>
              
              <div className="flex flex-col items-center">
                <div className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1 italic">VS</div>
                <div className="w-1 h-8 bg-white/5 rounded-full" />
                {official?.time && <div className="text-[8px] font-black text-slate-600 mt-1 uppercase">{official.time}</div>}
              </div>

              <div className="flex items-center gap-5 flex-1">
                <input 
                  type="number" 
                  disabled={hasResult}
                  value={pred?.away || 0}
                  onChange={(e) => updateScore(match.id, 'away', e.target.value)}
                  className={cn(
                    "w-14 h-14 glass rounded-2xl text-center font-black text-2xl outline-none transition-all",
                    hasResult ? "text-slate-500 border-white/5" : "text-[#d4af37] focus:border-[#d4af37] border-white/10"
                  )}
                />
                <span className="text-3xl drop-shadow-lg">{match.awayTeam.flag}</span>
                <div className="text-left">
                  <span className="font-black uppercase text-[10px] block leading-tight text-white/60 group-hover:text-white transition-colors">{match.awayTeam.name}</span>
                  {hasResult && <span className="text-sm font-black text-slate-500">{official.awayResult}</span>}
                </div>
              </div>

              {!hasResult && (
                <button 
                  onClick={() => handleSave(match.id)}
                  disabled={saving === match.id}
                  className="md:ml-4 w-14 h-14 rounded-2xl bg-white/5 text-white hover:bg-[#d4af37] hover:text-[#05070a] transition-all flex items-center justify-center disabled:opacity-50 border border-white/5"
                >
                  {saving === match.id ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <Save size={20} />}
                </button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

