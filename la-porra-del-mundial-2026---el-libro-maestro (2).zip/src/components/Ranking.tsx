import React, { useState, useEffect } from 'react';
import { collection, onSnapshot, query, orderBy, limit } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { motion } from 'motion/react';
import { Trophy, Medal, Crown } from 'lucide-react';
import { cn } from '../lib/utils';

export const Ranking = () => {
  const [standings, setStandings] = useState<any[]>([]);

  useEffect(() => {
    const q = query(collection(db, 'users'), orderBy('totalPoints', 'desc'), limit(25));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setStandings(data);
    });
    return unsubscribe;
  }, []);

  return (
    <div className="glass rounded-3xl overflow-hidden flex flex-col h-full bg-black/20">
      <div className="p-6 border-b border-white/5 flex items-center justify-between">
        <h2 className="font-bold uppercase tracking-widest text-xs text-slate-400">Líderes de la Porra</h2>
        <Trophy size={16} className="text-[#d4af37]" />
      </div>
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {standings.map((player, index) => (
          <motion.div 
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.05 }}
            key={player.id} 
            className={cn(
              "flex items-center gap-4 p-3 rounded-2xl border transition-all",
              index === 0 
                ? "bg-amber-500/10 border-amber-500/20 gold-glow" 
                : "bg-white/5 border-white/5 hover:bg-white/10"
            )}
          >
            <div className={cn(
              "text-xs font-black w-6 text-center",
              index === 0 ? "text-amber-500" : "text-slate-500"
            )}>
              {String(index + 1).padStart(2, '0')}
            </div>
            
            <div className="w-10 h-10 rounded-full bg-slate-800 border border-white/10 flex items-center justify-center font-bold text-xs text-white uppercase overflow-hidden">
               {player.displayName?.[0]}
            </div>

            <div className="flex-1 min-w-0">
              <div className={cn(
                "text-sm font-bold truncate tracking-tight",
                index === 0 ? "text-white" : "text-slate-300"
              )}>
                {player.displayName}
              </div>
              <div className="flex gap-1 mt-1 flex-wrap">
                {player.titles?.map((title: string) => (
                  <span key={title} className="text-[7px] bg-white/5 text-slate-400 px-1.5 py-0.5 rounded uppercase border border-white/5 tracking-tighter">
                    {title}
                  </span>
                ))}
              </div>
            </div>

            <div className="text-right">
              <div className="text-sm font-black text-white">{player.totalPoints}</div>
              <div className="text-[8px] text-slate-500 uppercase font-black tracking-tighter">PTS</div>
            </div>
          </motion.div>
        ))}
      </div>
      
      <div className="p-6 border-t border-white/5 bg-black/40 text-center">
        <div className="text-[10px] text-slate-500 uppercase mb-3 font-bold tracking-widest">Estado de Inscripción</div>
        <button className="text-[11px] font-black text-green-500 hover:text-green-400 transition-colors uppercase tracking-widest">
          Validación Bizum Pendiente →
        </button>
      </div>
    </div>
  );
};
