import React, { useState } from 'react';
import { signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import { auth } from '../lib/firebase';
import { motion } from 'motion/react';
import { Trophy, ShieldCheck, Zap } from 'lucide-react';

export const Login = () => {
  const [error, setError] = useState<string | null>(null);

  const handleLogin = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (err: any) {
      setError(err.message);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#05070a] p-4 text-[#e2e8f0] font-sans relative overflow-hidden">
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#d4af37]/10 blur-[120px] rounded-full animate-pulse"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-500/10 blur-[120px] rounded-full"></div>

      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full glass rounded-[40px] p-12 shadow-2xl relative z-10 card-gradient"
      >
        <div className="relative z-10">
          <div className="flex justify-center mb-10">
            <div className="w-20 h-20 bg-gradient-to-br from-amber-400 to-yellow-600 rounded-2xl flex items-center justify-center rotate-12 gold-glow border-2 border-white/20">
              <Trophy size={40} className="text-white drop-shadow-lg" />
            </div>
          </div>

          <h1 className="text-4xl font-black uppercase leading-none tracking-tighter mb-4 text-center italic">
            EL LIBRO<br /><span className="text-[#d4af37]">MAESTRO</span>
          </h1>
          <p className="text-[10px] uppercase opacity-40 text-center mb-10 tracking-[0.3em] font-bold">
            — MUNDIAL 2026 —
          </p>

          <div className="space-y-4 mb-10">
            <Feature icon={<ShieldCheck size={18} className="text-[#d4af37]" />} text="Security-First Architecture" />
            <Feature icon={<Zap size={18} className="text-[#d4af37]" />} text="Real-Time Sync Engine" />
            <Feature icon={<Trophy size={18} className="text-[#d4af37]" />} text="High Fidelity Standings" />
          </div>

          <button 
            onClick={handleLogin}
            className="w-full bg-gradient-to-r from-amber-500 to-yellow-600 text-white py-4 rounded-2xl font-black uppercase tracking-widest hover:scale-[1.02] transition-all flex items-center justify-center gap-3 cursor-pointer gold-glow active:scale-95 text-xs shadow-xl"
          >
            Sincronizar con Google
            <motion.span animate={{ x: [0, 4, 0] }} transition={{ repeat: Infinity, duration: 2 }}>
              →
            </motion.span>
          </button>

          {error && <p className="mt-6 text-red-400 text-[10px] font-mono text-center uppercase tracking-widest">{error}</p>}
        </div>
      </motion.div>
    </div>
  );
};

const Feature = ({ icon, text }: { icon: React.ReactNode, text: string }) => (
  <div className="flex items-center gap-3 border-b border-[#141414]/10 pb-2">
    <div className="text-[#141414]">{icon}</div>
    <span className="text-sm font-medium uppercase">{text}</span>
  </div>
);
