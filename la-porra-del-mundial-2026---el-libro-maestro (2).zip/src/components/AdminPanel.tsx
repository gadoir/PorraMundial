import React, { useState, useEffect } from 'react';
import { collection, query, getDocs, doc, updateDoc, setDoc, onSnapshot, writeBatch, getDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { ShieldCheck, UserCheck, Trophy, Calendar, Settings, Save, CheckCircle2, RefreshCw } from 'lucide-react';
import { cn } from '../lib/utils';
import { DAILY_MATCHES } from '../constants/worldcup';
import { calculateDailyPoints } from '../services/scoring';

export const AdminPanel = () => {
  const [users, setUsers] = useState<any[]>([]);
  const [matches, setMatches] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [recalculating, setRecalculating] = useState(false);
  const [activeAdminTab, setActiveAdminTab] = useState<'users' | 'matches'>('users');
  const [matchEdits, setMatchEdits] = useState<Record<string, any>>({});

  useEffect(() => {
    const fetchUsers = async () => {
      const q = query(collection(db, 'users'));
      const snap = await getDocs(q);
      setUsers(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    };
    fetchUsers();

    // Listen to official results/match overrides
    const unsubMatches = onSnapshot(collection(db, 'official_matches'), (snap) => {
      const data: Record<string, any> = {};
      snap.docs.forEach(d => { data[d.id] = d.data(); });
      setMatchEdits(data);
    });

    return () => unsubMatches();
  }, []);

  const togglePayment = async (userId: string, current: boolean) => {
    setLoading(true);
    await updateDoc(doc(db, 'users', userId), { isPaid: !current });
    setUsers(prev => prev.map(u => u.id === userId ? { ...u, isPaid: !current } : u));
    setLoading(false);
  };

  const saveMatchUpdate = async (matchId: string) => {
    setLoading(true);
    const data = matchEdits[matchId] || {};
    await setDoc(doc(db, 'official_matches', matchId), data, { merge: true });
    setLoading(false);
  };

  const recalculateAllPoints = async () => {
    setRecalculating(true);
    try {
      const usersSnap = await getDocs(query(collection(db, 'users')));
      
      for (const userDoc of usersSnap.docs) {
        const userId = userDoc.id;
        let dailyPoints = 0;
        let exactHits = 0;

        for (const match of DAILY_MATCHES) {
          const predDoc = await getDoc(doc(db, 'predictions', userId, 'daily', match.id));
          const official = matchEdits[match.id];

          if (predDoc.exists() && official && official.homeResult !== null && official.awayResult !== null) {
            const pred = predDoc.data();
            const pts = calculateDailyPoints(official.homeResult, official.awayResult, pred.homeScore, pred.awayScore);
            dailyPoints += pts;
            if (pts === 10) exactHits++;
          }
        }

        await updateDoc(doc(db, 'users', userId), {
          totalPoints: dailyPoints, // simplified for now
          dailyPoints,
          stats: { exactDaily: exactHits }
        });
      }
      alert('Puntos recalculados con éxito');
    } catch (e) {
      console.error(e);
      alert('Error al recalcular');
    }
    setRecalculating(false);
  };

  const updateMatchField = (matchId: string, field: string, value: any) => {
    setMatchEdits(prev => ({
      ...prev,
      [matchId]: {
        ...(prev[matchId] || {}),
        [field]: value
      }
    }));
  };

  return (
    <div className="space-y-8">
      <header className="flex flex-col md:flex-row items-start md:items-end justify-between gap-6">
        <div>
          <h2 className="text-4xl font-black uppercase tracking-tighter italic">PANEL DE <span className="text-[#d4af37]">ADMINISTRACIÓN</span></h2>
          <p className="text-xs font-bold text-slate-500 uppercase tracking-widest mt-1 opacity-60">Control maestro de usuarios e inscripciones del Mundial 2026</p>
        </div>
        <div className="flex glass bg-white/5 rounded-2xl p-1 shrink-0">
          <button 
            onClick={() => setActiveAdminTab('users')}
            className={cn("px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all", activeAdminTab === 'users' ? "bg-[#d4af37] text-[#05070a]" : "text-slate-400 hover:text-white")}
          >
            Usuarios
          </button>
          <button 
            onClick={() => setActiveAdminTab('matches')}
            className={cn("px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all", activeAdminTab === 'matches' ? "bg-[#d4af37] text-[#05070a]" : "text-slate-400 hover:text-white")}
          >
            Resultados
          </button>
          <button 
            onClick={recalculateAllPoints}
            disabled={recalculating}
            className="px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all text-slate-400 hover:text-white flex items-center gap-2"
          >
            <RefreshCw size={14} className={recalculating ? "animate-spin" : ""} /> Recalcular
          </button>
        </div>
      </header>

      {activeAdminTab === 'users' ? (
        <div className="glass rounded-[32px] overflow-hidden border border-white/5 bg-black/20 shadow-2xl">
          <div className="bg-white/5 p-6 border-b border-white/5 flex items-center justify-between">
            <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Directorio de Jugadores</h3>
            <ShieldCheck size={16} className="text-[#d4af37]" />
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-black/20 text-[10px] font-bold uppercase tracking-widest text-slate-500">
                <tr>
                  <th className="p-6">Jugador</th>
                  <th className="p-6">Identidad</th>
                  <th className="p-6">Estado</th>
                  <th className="p-6 text-right">Acciones</th>
                </tr>
              </thead>
              <tbody className="text-sm">
                {users.map(u => (
                  <tr key={u.id} className="border-b border-white/5 hover:bg-white/5 transition-colors group">
                    <td className="p-6">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-full bg-slate-800 border border-white/10 flex items-center justify-center font-bold text-white uppercase overflow-hidden">
                          {u.displayName?.[0]}
                        </div>
                        <span className="font-bold text-white group-hover:text-[#d4af37] transition-colors">{u.displayName}</span>
                      </div>
                    </td>
                    <td className="p-6 text-slate-500 font-mono text-[10px] italic">{u.email}</td>
                    <td className="p-6">
                      {u.isPaid ? (
                        <div className="text-green-500 font-black text-[10px] uppercase tracking-widest flex items-center gap-2">
                          <CheckCircle2 size={14} /> Validado
                        </div>
                      ) : (
                        <div className="text-amber-500/50 font-black text-[10px] uppercase tracking-widest">Pendiente</div>
                      )}
                    </td>
                    <td className="p-6 text-right">
                      <button 
                        onClick={() => togglePayment(u.id, u.isPaid)}
                        className={cn("px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest border transition-all", u.isPaid ? "border-red-500/30 text-red-500" : "border-[#d4af37]/30 text-[#d4af37]")}
                      >
                        {u.isPaid ? 'Revocar' : 'Validar'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="glass rounded-[32px] overflow-hidden border border-white/5 bg-black/20 p-8">
            <h3 className="text-xl font-black uppercase tracking-tighter mb-8 italic">Gestión de <span className="text-[#d4af37]">Resultados Reales</span></h3>
            <div className="grid grid-cols-1 gap-4 overflow-y-auto max-h-[600px] pr-2">
              {DAILY_MATCHES.map(match => {
                const edit = matchEdits[match.id] || {};
                return (
                  <div key={match.id} className="glass bg-white/5 p-6 rounded-[24px] border border-white/5 flex flex-wrap items-center justify-between gap-6 group hover:border-[#d4af37]/20 transition-all">
                    <div className="flex items-center gap-4 w-full md:w-auto">
                      <Calendar size={18} className="text-slate-500" />
                      <input 
                        type="date" 
                        value={edit.date || match.date}
                        onChange={(e) => updateMatchField(match.id, 'date', e.target.value)}
                        className="bg-transparent border-b border-white/10 text-xs font-black text-white focus:border-[#d4af37] outline-none py-1"
                      />
                      <input 
                        type="time" 
                        value={edit.time || "21:00"}
                        onChange={(e) => updateMatchField(match.id, 'time', e.target.value)}
                        className="bg-transparent border-b border-white/10 text-xs font-black text-white focus:border-[#d4af37] outline-none py-1"
                      />
                    </div>

                    <div className="flex items-center gap-4 flex-1 justify-center">
                      <div className="flex items-center gap-2 text-right">
                        <span className="text-[10px] font-bold text-slate-400 uppercase hidden sm:block">{match.homeTeam.name}</span>
                        <input 
                          type="number"
                          placeholder="-"
                          value={edit.homeResult ?? ""}
                          onChange={(e) => updateMatchField(match.id, 'homeResult', e.target.value === "" ? null : parseInt(e.target.value))}
                          className="w-10 h-10 glass text-center font-black text-[#d4af37] text-lg rounded-xl outline-none border border-white/10 focus:border-[#d4af37]"
                        />
                      </div>
                      <div className="text-[10px] font-black text-slate-600">VS</div>
                      <div className="flex items-center gap-2">
                        <input 
                          type="number"
                          placeholder="-"
                          value={edit.awayResult ?? ""}
                          onChange={(e) => updateMatchField(match.id, 'awayResult', e.target.value === "" ? null : parseInt(e.target.value))}
                          className="w-10 h-10 glass text-center font-black text-[#d4af37] text-lg rounded-xl outline-none border border-white/10 focus:border-[#d4af37]"
                        />
                        <span className="text-[10px] font-bold text-slate-400 uppercase hidden sm:block">{match.awayTeam.name}</span>
                      </div>
                    </div>

                    <button 
                      onClick={() => saveMatchUpdate(match.id)}
                      className="w-10 h-10 flex items-center justify-center rounded-xl bg-green-500/10 text-green-500 border border-green-500/30 hover:bg-green-500 hover:text-white transition-all shadow-lg"
                    >
                      <Save size={18} />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
