import React from 'react';
import { useAuth } from './context/AuthContext';
import { Login } from './components/Login';
import { Ranking } from './components/Ranking';
import { GroupPhase } from './components/GroupPhase';
import { DailyPhase } from './components/DailyPhase';
import { AdminPanel } from './components/AdminPanel';
import { BracketPhase } from './components/BracketPhase';
import { FinalPhase } from './components/FinalPhase';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Trophy, 
  LayoutDashboard, 
  Grid3x3, 
  GitFork, 
  Calendar, 
  Target,
  LogOut,
  ShieldAlert
} from 'lucide-react';
import { auth } from './lib/firebase';
import { cn } from './lib/utils';

const DasboardStatCard = ({ label, value, max, progress, color }: { label: string, value: number, max: number, progress: number, color: 'green' | 'amber' }) => (
  <div className="p-6 rounded-2xl border border-white/5 bg-black/30">
    <div className="text-[10px] text-slate-500 font-bold uppercase mb-3 tracking-widest">{label}</div>
    <div className="flex justify-between items-end mb-4">
      <div className="text-3xl font-black">
        {value}<span className="text-sm text-slate-600 font-normal ml-1">/ {max}</span>
      </div>
      <div className={cn("text-[10px] font-bold uppercase", color === 'green' ? "text-green-500" : "text-amber-500 italic")}>
        {color === 'green' ? "+12 pts hoy" : "Bloqueado"}
      </div>
    </div>
    <div className="w-full bg-white/5 h-2 rounded-full">
      <motion.div 
        initial={{ width: 0 }}
        animate={{ width: `${progress}%` }}
        transition={{ duration: 1, ease: "easeOut" }}
        className={cn(
          "h-full rounded-full",
          color === 'green' ? "bg-green-500 shadow-[0_0_12px_rgba(34,197,94,0.4)]" : "bg-amber-500 shadow-[0_0_12px_rgba(245,158,11,0.4)]"
        )}
      />
    </div>
  </div>
);

const AchievementIcon = ({ icon, label, active = false }: { icon: string, label: string, active?: boolean }) => (
  <div className={cn("text-center flex flex-col items-center gap-1", !active && "opacity-30 grayscale")}>
    <div className="text-3xl transform hover:scale-110 transition-transform cursor-pointer drop-shadow-[0_0_10px_rgba(255,255,255,0.2)]">{icon}</div>
    <div className="text-[8px] font-black text-slate-500 uppercase tracking-tighter w-16 leading-tight">{label}</div>
  </div>
);

export default function App() {
  const { user, profile, loading } = useAuth();
  const [activeTab, setActiveTab] = React.useState('dashboard');

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-[#05070a]">
      <div className="w-12 h-12 border-4 border-[#d4af37] border-t-transparent rounded-full animate-spin"></div>
    </div>
  );

  if (!user) return <Login />;

  const tabs = [
    { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={18} /> },
    { id: 'f1', label: 'Fase 1: Grupos', icon: <Grid3x3 size={18} /> },
    { id: 'f2', label: 'Fase 2: Bracket', icon: <GitFork size={18} /> },
    { id: 'daily', label: 'Diarios', icon: <Calendar size={18} /> },
    { id: 'f3', label: 'Gran Final', icon: <Target size={18} /> },
  ];

  const totalValidatedUsers = 25; // This should be calculated from actual users, but for now fixed
  const pot = totalValidatedUsers * 30;
  const earnings = profile?.totalPoints ? (
    // Simple logic: if in top 3, show estimated prize
    profile.totalPoints >= 10 ? pot * 0.6 : 0 // Fake logic for immediate feedback
  ) : 0;

  if (profile?.isAdmin) {
    tabs.push({ id: 'admin', label: 'Admin', icon: <ShieldAlert size={18} /> });
  }

  return (
    <div className="min-h-screen p-4 flex flex-col md:flex-row gap-4 h-full overflow-hidden bg-[#05070a]">
      {/* Sidebar - Immersive UI Glass Container */}
      <nav className="w-full md:w-64 glass rounded-3xl flex flex-col overflow-hidden shrink-0">
        <div className="p-8 border-b border-white/5">
          <div className="text-[10px] uppercase tracking-widest text-[#94a3b8] font-bold mb-1">Mundial 2026</div>
          <div className="text-xl font-black text-white italic tracking-tighter">EL LIBRO MAESTRO</div>
        </div>

        <div className="flex-1 overflow-y-auto py-6 flex md:flex-col overflow-x-auto">
          {/* Prize Indicator */}
          <div className="mx-6 mb-4 p-4 rounded-2xl bg-gradient-to-br from-amber-500/20 to-yellow-600/5 border border-amber-500/30">
            <div className="text-[8px] font-black uppercase text-amber-500/60 mb-1 tracking-widest">Bote Acumulado</div>
            <div className="text-xl font-black text-white italic">{pot} €</div>
            <div className="text-[8px] font-bold text-slate-500 uppercase mt-1">2€ Commision / 30€ Pot</div>
          </div>

          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={cn(
                "flex items-center gap-3 px-8 py-4 text-[11px] font-bold uppercase tracking-widest transition-all whitespace-nowrap md:w-full border-l-4",
                activeTab === tab.id 
                  ? "border-[#d4af37] text-[#d4af37] active-step-gradient" 
                  : "border-transparent text-slate-400 hover:text-white"
              )}
            >
              <span className={cn("w-2 h-2 rounded-full", activeTab === tab.id ? "bg-[#d4af37] gold-glow" : "bg-slate-700")}></span>
              {tab.label}
            </button>
          ))}
        </div>

        <div className="p-6 bg-black/20 mt-auto">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-400 to-yellow-600 border-2 border-white/20 flex items-center justify-center font-black text-white text-sm">
              {profile?.displayName?.[0]}
            </div>
            <div>
              <div className="text-sm font-bold text-white truncate max-w-[140px]">{profile?.displayName}</div>
              <div className="text-[10px] text-[#d4af37] font-bold uppercase tracking-tighter">GANANCIA: {earnings} €</div>
            </div>
          </div>
          <button 
            onClick={() => auth.signOut()}
            className="w-full bg-white/5 py-2.5 rounded-xl text-[10px] font-bold uppercase tracking-widest text-slate-400 hover:bg-white/10 hover:text-white transition-all flex items-center justify-center gap-2"
          >
            <LogOut size={14} /> Cerrar Sesión
          </button>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto flex flex-col gap-4">
        {/* Header Ribbon */}
        <header className="h-24 glass rounded-3xl flex items-center justify-between px-8 shrink-0">
          <div className="flex gap-12">
            <div className="flex flex-col">
              <span className="text-[10px] text-slate-500 uppercase font-bold tracking-widest mb-1">Puntos Totales</span>
              <span className="text-3xl font-black text-[#d4af37] leading-none">
                {profile?.totalPoints || 0} <span className="text-xs text-slate-400 font-normal ml-0.5 italic">pts</span>
              </span>
            </div>
            <div className="hidden lg:flex flex-col">
              <span className="text-[10px] text-slate-500 uppercase font-bold tracking-widest mb-1">Tu Podio</span>
              <span className="text-3xl font-black text-white italic leading-none">
                #01 <span className="text-xs text-slate-400 font-normal ml-0.5">/ {totalValidatedUsers}</span>
              </span>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="hidden sm:block px-5 py-2.5 rounded-full bg-white/5 border border-white/10 text-[10px] font-bold uppercase tracking-widest text-slate-400">
               💰 Ganando: <span className="text-green-500 font-black">{earnings} €</span>
            </div>
            <button 
              onClick={() => setActiveTab('daily')}
              className="px-6 py-2.5 rounded-full bg-amber-600/20 text-white border border-amber-500/30 font-bold text-[10px] uppercase tracking-widest hover:bg-amber-600 transition-all gold-glow"
            >
              MI PRONÓSTICO
            </button>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto w-full">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.2 }}
              className="h-full"
            >
              {activeTab === 'dashboard' && (
                <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 h-full">
                  <div className="xl:col-span-2 space-y-4">
                    {/* Winner Celebration Banner */}
                    {profile?.totalPoints && profile.totalPoints > 0 && (
                      <motion.div 
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        className="glass !bg-amber-500/20 border border-amber-500/50 rounded-3xl p-6 relative overflow-hidden"
                      >
                         <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10"></div>
                         <div className="relative z-10 flex items-center justify-between">
                            <div className="flex items-center gap-4">
                               <div className="w-12 h-12 bg-amber-500 rounded-2xl flex items-center justify-center gold-glow">
                                  <Trophy size={24} className="text-[#05070a]" />
                               </div>
                               <div>
                                  <h3 className="font-black text-white italic uppercase tracking-tighter text-xl">¿EL REY DEL LIBRO MAESTRO?</h3>
                                  <p className="text-[10px] font-bold text-amber-500 uppercase tracking-widest">Actualmente lideras la clasificación. Estimado: {earnings} €</p>
                               </div>
                            </div>
                            <div className="hidden sm:block text-right">
                               <div className="text-2xl font-black text-white italic">🏆 +{profile.totalPoints} PTS</div>
                               <div className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">Aplastando a la competencia</div>
                            </div>
                         </div>
                      </motion.div>
                    )}

                    <section className="glass rounded-3xl p-8 card-gradient relative overflow-hidden">
                      <div className="absolute -top-12 -right-12 w-48 h-48 bg-amber-500/10 blur-3xl rounded-full"></div>
                      <div className="flex justify-between items-center mb-8">
                        <h2 className="text-xl font-bold flex items-center gap-3">
                          <Trophy className="text-[#d4af37]" /> Tu Estado en el Podio
                        </h2>
                        <div className="flex gap-6 text-[10px] font-bold uppercase tracking-widest">
                          <span className={cn("pb-1 transition-all cursor-pointer", activeTab === 'dashboard' ? "text-[#d4af37] border-b-2 border-[#d4af37]" : "text-slate-500")} onClick={() => setActiveTab('dashboard')}>Resumen</span>
                          <span className="text-slate-500 hover:text-white cursor-pointer transition-colors" onClick={() => setActiveTab('f2')}>Mi Bracket</span>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <DasboardStatCard label="Aciertos Totales" value={profile?.stats?.exactDaily || 0} max={35} progress={(profile?.stats?.exactDaily || 0)/35 * 100} color="green" />
                        <DasboardStatCard label="Ganancia Estimada" value={earnings} max={pot * 0.6} progress={earnings > 0 ? 100 : 0} color="amber" />
                      </div>

                      <div className="mt-8">
                        <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-4">Módulo de Pago & Validación</div>
                        <div className="glass bg-white/5 p-6 rounded-2xl border-white/10 flex flex-col md:flex-row items-center justify-between gap-6">
                           <div className="flex-1">
                             <p className="text-sm text-slate-300 leading-relaxed italic">
                               "Para participar en El Libro Maestro, envía 32€ vía Bizum al administrador. Tu perfil se validará automáticamente tras la comprobación."
                             </p>
                           </div>
                           <a 
                            href={`https://wa.me/34600000000?text=PORRA+${profile?.displayName}`}
                            target="_blank"
                            className="px-6 py-3 rounded-xl bg-[#25D366]/10 text-[#25D366] border border-[#25D366]/30 font-bold uppercase text-[10px] tracking-widest hover:bg-[#25D366] hover:text-white transition-all whitespace-nowrap"
                          >
                            Validar Inscripción →
                          </a>
                        </div>
                      </div>
                    </section>

                    <section className="glass rounded-3xl p-8 border border-white/5 bg-white/5 flex flex-col justify-center">
                      <div className="text-[10px] font-black text-[#d4af37] uppercase tracking-[0.25em] mb-2 text-center">Protocolo de Desempate</div>
                      <div className="flex flex-wrap justify-center gap-x-6 gap-y-2">
                        {["Fase Final", "Marcadores Exactos", "Fase 2", "Fase 1"].map((step, i) => (
                          <div key={step} className="flex items-center gap-2">
                            <span className="text-slate-500 font-mono text-[10px]">{i + 1}.</span>
                            <span className="text-[10px] font-bold text-slate-300 uppercase tracking-wider">{step}</span>
                          </div>
                        ))}
                      </div>
                    </section>
                  </div>

                  <div className="xl:col-span-1 flex flex-col gap-4">
                    <Ranking />
                    
                    <section className="h-32 glass rounded-3xl p-4 flex items-center justify-center gap-8">
                      <AchievementIcon icon="👑" label="Rey del Directo" active />
                      <AchievementIcon icon="📏" label="Maestro Grupos" />
                      <AchievementIcon icon="📐" label="Arquitecto" />
                    </section>
                  </div>
                </div>
              )}

              {activeTab === 'f1' && <GroupPhase />}
              {activeTab === 'f2' && <BracketPhase />}
              {activeTab === 'daily' && <DailyPhase />}
              {activeTab === 'f3' && <FinalPhase />}
              {activeTab === 'admin' && <AdminPanel />}

              {['dashboard', 'f1', 'f2', 'daily', 'f3', 'admin'].indexOf(activeTab) === -1 && (
                <div className="h-full glass rounded-3xl flex flex-col items-center justify-center py-24 text-center">
                  <div className="w-24 h-24 bg-white/5 flex items-center justify-center rounded-full mb-8 border border-white/10">
                    <Grid3x3 className="text-white/20" size={48} />
                  </div>
                  <h2 className="text-3xl font-black uppercase tracking-tighter mb-2">Módulo en Construcción</h2>
                  <p className="text-xs font-bold text-[#d4af37] uppercase tracking-widest opacity-60">— Disponible Próximamente —</p>
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}


