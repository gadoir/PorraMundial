import { SCORING_RULES } from '../constants/worldcup';

export interface GroupPrediction {
  groupId: string;
  top3: string[]; // Team IDs in order
}

export interface GroupResult {
  groupId: string;
  top3: string[]; // Final official top 3
}

export function calculateF1Points(predictions: GroupPrediction[], results: GroupResult[]): number {
  let points = 0;
  predictions.forEach(pred => {
    const result = results.find(r => r.groupId === pred.groupId);
    if (!result) return;

    pred.top3.forEach((teamId, index) => {
      if (result.top3.includes(teamId)) {
        points += SCORING_RULES.F1_TOP3_MEMBER;
        if (result.top3[index] === teamId) {
          points += SCORING_RULES.F1_EXACT_POS;
        }
      }
    });
  });
  return points;
}

export function calculateDailyPoints(home: number, away: number, predHome: number, predAway: number): number {
  // Signo
  const resultSign = Math.sign(home - away);
  const predSign = Math.sign(predHome - predAway);

  if (home === predHome && away === predAway) {
    return SCORING_RULES.DAILY_EXACT;
  }
  
  if (resultSign === predSign) {
    return SCORING_RULES.DAILY_SIGN;
  }

  return 0;
}

export function calculateFinalPoints(home: number, away: number, predHome: number, predAway: number): number {
  const resultSign = Math.sign(home - away);
  const predSign = Math.sign(predHome - predAway);
  const resultDiff = home - away;
  const predDiff = predHome - predAway;

  if (home === predHome && away === predAway) {
    return SCORING_RULES.FINAL_EXACT;
  }
  
  if (resultDiff === predDiff) {
    return SCORING_RULES.FINAL_DIFF;
  }
  
  if (resultSign === predSign) {
    return SCORING_RULES.FINAL_SIGN;
  }

  return 0;
}

// Hierarchical Tie-breaking
export function compareUsers(a: any, b: any): number {
  // 1º Puntos Fase 3
  if (b.f3Points !== a.f3Points) return b.f3Points - a.f3Points;
  // 2º Exactos Partido del Día
  if (b.stats.exactDaily !== a.stats.exactDaily) return b.stats.exactDaily - a.stats.exactDaily;
  // 3º Puntos Fase 2
  if (b.f2Points !== a.f2Points) return b.f2Points - a.f2Points;
  // 4º Puntos Fase 1
  return b.f1Points - a.f1Points;
}
